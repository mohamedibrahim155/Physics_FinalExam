Starwars X-Wing 3ds model

Once loaded in, you can load a texture to the model. Once the texture is loaded in, you
 will find that may will not fully appear on this model until you select the 
Texture Co-ordinates tick box on the control window.
Once this has been selected, the texture should then appear on the stardestroyer.